<script setup>
import { RouterLink, RouterView } from 'vue-router'
</script>

<template>


  <RouterView />
</template>


<style>
body {
  width: 100%;
  margin: 0;
  padding: 0;
  border: 0;
}
</style>
